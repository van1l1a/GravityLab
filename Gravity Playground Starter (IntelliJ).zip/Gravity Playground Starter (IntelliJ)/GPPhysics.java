
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class GPPhysics {
    public static boolean play = true;
    public static final int EMPTY = 0;
    public static final int ROCK = 1;
    public static final int SAND = 2;
    public static final int CLEAR = 3;
    public static final int FALLSAND = 4;
    public static final int WATER = 5;
    public static final int SPONGE = 6;
    public static final int HOURGLASS = 7;
    public static final int LAVA = 8;
    public static final int MAGMA = 10;
    public static final int STEAM = 9;
    public static final int WOOD = 11;
    public static final int FIRE = 12;
    public static final int INFECTION = 13;
    public static final int LEAF = 14;
    public static final int RAPIDINFECTION = 15;
    public static final int DIRT = 16;
    public static final int SOIL = 17;
    public static final int SAPLING = 18;
    public static final int CLEARSPONGE = 19;
    public static final int CLEARLAVA = 20;
    public static final int CLEARMAGMA = 21;
    public static final int CLEARSTEAM = 22;
    public static final int CLEARINFECTION = 23;
    public static final int CLEARFIRE = 24;
    public static final int CLEARLEAVES = 25;
    public static final int CLEARWOOD = 26;
    public static final int CLEARSAND = 27;
    public static final int CLEARROCK = 28;
    public static final int CLEARFALLSAND = 29;
    public static final int CLEARWATER = 30;
    public static final int CLEARSAPLINGS = 31;
    public static final int LAVA2 = 35;
    public static final int WATER2 = 34;
    public static final int BORDER = 32;
    public static final int DEADLEAF = 33;

    private final AtomicBoolean done = new AtomicBoolean();
    //do not add any more fields
    private final int[][] grid;
    private final GPDisplay display;
    int count2 = 0;
    int z = 1;
    int x = 0;
    int y = 0;
    int w = 3;
    int v = 0;
    int u = 0;
    int t = 1000;
    int s = 0;
    int r = 20000;
    int q = 0;
    int p = 500;
    int waterCount = 0;
    int seedCount = 0;

    public GPPhysics(int numRows, int numCols) {
        String[] names;

        names = new String[33];

        names[CLEAR] = "Clear";

        names[EMPTY] = "Empty";

        names[ROCK] = "Rock";

        names[SAND] = "Str sand";

        names[FALLSAND] = "Sand";

        names[WATER] = "Water";

        names[SPONGE] = "Sponge";

        names[HOURGLASS] = "⌛︎";

        names[LAVA] = "Lava";

        names[CLEARSAND] = "Clear str sand";

        names[MAGMA] = "Magma";

        names[STEAM] = "Steam";

        names[WOOD] = "Wood";

        names[FIRE] = "Fire";

        names[CLEARROCK] = "Clear rock";

        names[CLEARFALLSAND] = "Clear sand";

        names[CLEARWATER] = "Clear water";

        names[CLEARSPONGE] = "Clear sponge";

        names[CLEARLAVA] = "Clear lava";

        names[CLEARMAGMA] = "Clear magma";

        names[CLEARSTEAM] = "Clear steam";

        names[CLEARWOOD] = "Clear wood";

        names[CLEARFIRE] = "Clear fire";

        names[INFECTION] = "Infection";

        names[CLEARINFECTION] = "Clear infection";

        names[LEAF] = "Leaf";

        names[CLEARLEAVES] = "Clear leaves";

        names[RAPIDINFECTION] = "Rapid infection";

        names[DIRT] = "Dirt";

        names[SOIL] = "Soil";

        names[SAPLING] = "Sapling";

        names[CLEARSAPLINGS] = "Clear saplings";


        grid = new int[numRows][numCols];
        display = new GPDisplay("Gravity Playground", numRows, numCols, names);
    }

    //called when the user clicks on a location using the given tool
    private void locationClicked(int row, int col, int tool) {
        if (display.getBrushSize() > 4) {
            for (int i = 0; i < display.getBrushSize() / 2; i++) {
                for (int j = 0; j < display.getBrushSize() / 2; j++) {

                    if (grid[row][col] == EMPTY || tool == EMPTY || grid[row][col] == tool || grid[row][col] != EMPTY) {
                        if (grid[row][col] == EMPTY) {
                            grid[row][col] = tool;
                        }
                        if (row + i < grid.length && (grid[row + i][col] == EMPTY || tool == EMPTY)) {
                            grid[row + i][col] = tool;
                        }
                        if (col + j < grid[0].length && (grid[row][col + j] == EMPTY || tool == EMPTY)) {
                            grid[row][col + j] = tool;
                        }
                        if (row - i > 0 && (grid[row - i][col] == EMPTY || tool == EMPTY)) {
                            grid[row - i][col] = tool;
                        }
                        if (col - j > 0 && (grid[row][col - j] == EMPTY || tool == EMPTY)) {
                            grid[row][col - j] = tool;
                        }
                        if ((row + i < grid.length && col + j < grid[0].length) && (grid[row + i][col + j] == EMPTY || tool == EMPTY)) {
                            grid[row + i][col + j] = tool;
                        }
                        if ((row + i < grid.length && col - j > 0) && (grid[row + i][col - j] == EMPTY || tool == EMPTY)) {
                            grid[row + i][col - j] = tool;
                        }
                        if ((row - i > 0 && col + j < grid[0].length) && (grid[row - i][col + j] == EMPTY || tool == EMPTY)) {
                            grid[row - i][col + j] = tool;
                        }
                        if ((row - i > 0 && col - j > 0) && (grid[row - i][col - j] == EMPTY || tool == EMPTY)) {
                            grid[row - i][col - j] = tool;
                        }
                        if (tool == LAVA) {
                            if (Math.random() > 0.95) {
                                if (row + i < grid.length && (grid[row + i][col] == EMPTY || grid[row + i][col] == LAVA)) {
                                    if (Math.random() > 0.7) {
                                        grid[row + i][col] = LAVA2;
                                    }
                                }
                                if (col + j < grid[0].length && (grid[row][col + j] == EMPTY || grid[row][col + j] == LAVA)) {
                                    if (Math.random() > 0.7) {
                                        grid[row][col + j] = LAVA2;
                                    }
                                }
                                if (row - i > 0 && (grid[row - i][col] == EMPTY || grid[row - i][col] == LAVA)) {
                                    if (Math.random() > 0.7) {
                                        grid[row - i][col] = LAVA2;
                                    }
                                }
                                if (col - j > 0 && (grid[row][col - j] == EMPTY || grid[row][col - j] == LAVA)) {
                                    if (Math.random() > 0.7) {
                                        grid[row][col - j] = LAVA2;
                                    }
                                }
                                if ((row + i < grid.length && col + j < grid[0].length) && (grid[row + i][col + j] == EMPTY || grid[row + i][col + j] == LAVA)) {
                                    if (Math.random() > 0.7) {
                                        grid[row + i][col + j] = LAVA2;
                                    }
                                }
                                if ((row + i < grid.length && col - j > 0) && (grid[row + i][col - j] == EMPTY || grid[row + i][col - j] == LAVA)) {
                                    if (Math.random() > 0.7) {
                                        grid[row + i][col - j] = LAVA2;
                                    }
                                }
                                if ((row - i > 0 && col + j < grid[0].length) && (grid[row - i][col + j] == EMPTY || grid[row - i][col + j] == LAVA)) {
                                    if (Math.random() > 0.7) {
                                        grid[row - i][col + j] = LAVA2;
                                    }
                                }
                                if ((row - i > 0 && col - j > 0) && (grid[row - i][col - j] == EMPTY || grid[row - i][col - j] == LAVA)) {
                                    if (Math.random() > 0.7) {
                                        grid[row - i][col - j] = LAVA2;
                                    }
                                }
                            }
                        }
                        if (tool == WATER) {
                            if (Math.random() > 0.98) {
                                if (row + i < grid.length && (grid[row + i][col] == EMPTY || grid[row + i][col] == WATER)) {
                                    if (Math.random() > 0.92) {
                                        grid[row + i][col] = WATER2;
                                    }
                                }
                                if (col + j < grid[0].length && (grid[row][col + j] == EMPTY || grid[row][col + j] == WATER)) {
                                    if (Math.random() > 0.92) {
                                        grid[row][col + j] = WATER2;
                                    }
                                }
                                if (row - i > 0 && (grid[row - i][col] == EMPTY || grid[row - i][col] == WATER)) {
                                    if (Math.random() > 0.92) {
                                        grid[row - i][col] = WATER2;
                                    }
                                }
                                if (col - j > 0 && (grid[row][col - j] == EMPTY || grid[row][col - j] == WATER)) {
                                    if (Math.random() > 0.92) {
                                        grid[row][col - j] = WATER2;
                                    }
                                }
                                if ((row + i < grid.length && col + j < grid[0].length) && (grid[row + i][col + j] == EMPTY || grid[row + i][col + j] == WATER)) {
                                    if (Math.random() > 0.65) {
                                        grid[row + i][col + j] = WATER2;
                                    }
                                }
                                if ((row + i < grid.length && col - j > 0) && (grid[row + i][col - j] == EMPTY || grid[row + i][col - j] == WATER)) {
                                    if (Math.random() > 0.65) {
                                        grid[row + i][col - j] = WATER2;
                                    }
                                }
                                if ((row - i > 0 && col + j < grid[0].length) && (grid[row - i][col + j] == EMPTY || grid[row - i][col + j] == WATER)) {
                                    if (Math.random() > 0.65) {
                                        grid[row - i][col + j] = WATER2;
                                    }
                                }
                                if ((row - i > 0 && col - j > 0) && (grid[row - i][col - j] == EMPTY || grid[row - i][col - j] == WATER)) {
                                    if (Math.random() > 0.65) {
                                        grid[row - i][col - j] = WATER2;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }else{
            if(grid[row][col] == EMPTY || grid[row][col] == tool||tool == EMPTY){grid[row][col] = tool;}}
    }

    //copies each element of grid into the display
    public void updateDisplay() {


        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (i == grid.length - 1) {
                    grid[i][j] = BORDER;
                }
                if (j == grid[0].length - 1) {
                    grid[i][j] = BORDER;
                }
                if (j == 0) {
                    grid[i][j] = BORDER;
                }
                if (i == 0) {
                    grid[i][j] = BORDER;
                }
                if (grid[i][j] == BORDER) {
                    display.setColor(i, j, 238, 238, 238);
                    //display.setColor(i, j, 255, 0, 0);

                }
                if (display.getTool() == CLEARINFECTION) {
                    if (grid[i][j] == INFECTION || grid[i][j] == RAPIDINFECTION) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARSAPLINGS) {
                    if (grid[i][j] == SAPLING) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARLEAVES) {
                    if (grid[i][j] == LEAF || grid[i][j] == DEADLEAF) {
                        grid[i][j] = EMPTY;
                    }
                }

                if (display.getTool() == CLEARSAND) {
                    if (grid[i][j] == SAND) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARROCK) {
                    if (grid[i][j] == ROCK) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARFALLSAND) {
                    if (grid[i][j] == FALLSAND) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARWATER) {
                    if (grid[i][j] == WATER) {
                        grid[i][j] = EMPTY;
                    }
                    if (grid[i][j] == WATER2) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARSPONGE) {
                    if (grid[i][j] == SPONGE) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARLAVA) {
                    if (grid[i][j] == LAVA) {
                        grid[i][j] = EMPTY;
                    }
                    if (grid[i][j] == LAVA2) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARMAGMA) {
                    if (grid[i][j] == MAGMA) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARSTEAM) {
                    if (grid[i][j] == STEAM) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARWOOD) {
                    if (grid[i][j] == WOOD) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEARFIRE) {
                    if (grid[i][j] == FIRE) {
                        grid[i][j] = EMPTY;
                    }
                }
                if (display.getTool() == CLEAR) {
                    if (grid[i][j] != BORDER) {
                        display.setColor(i, j, 0, 0, 0);
                        grid[i][j] = EMPTY;
                    }
                    count2 = 0;
                    waterCount = 0;
                    z = 1;
                    x = 0;
                    y = 0;
                    w = 3;
                    v = 0;
                    u = 0;
                    t = 1000;
                    s = 0;
                    r = 20000;
                    q = 0;
                    p = 500;
                }


                final long COLOR_CYCLE_PERIOD_MS =   60 * 60 * 1000; // 5 minutes
                final int[][] COLOR_GRADIENT = {
                        {0, 0, 0},          // midnight (black)
                        {0, 0, 128},        // dawn (navy blue)
                        {5, 46, 88},        // early morning (dark blue)
                        {0, 0, 240},        // mid-morning (bright blue)
                        {255, 255, 100},      // noon (yellow)
                        {255, 255, 153},    // afternoon (pale yellow)
                        {255, 255, 255},    // sunset (white)
                        {255, 204, 153},    // dusk (orange)
                        {255, 153, 100},      // evening (dark orange)
                        {255, 133, 133},        // late evening (red)
                        {102, 55, 102},      // night (purple)
                        {0, 0, 0}           // midnight (black)
                };

                if(grid[i][j] == EMPTY) {
                    long currentTime = System.currentTimeMillis();
                    long cycleTime = currentTime % (20 * 60 * 1000);
                    int colorIndex = (int) Math.floor((double) cycleTime / (20 * 60 * 1000 / COLOR_GRADIENT.length));
                    double ombre = ((double) cycleTime % (20 * 60 * 1000 / COLOR_GRADIENT.length)) / (20 * 60 * 1000 / COLOR_GRADIENT.length);
                    int[] color1 = COLOR_GRADIENT[colorIndex];
                    int[] color2 = COLOR_GRADIENT[(colorIndex + 1) % COLOR_GRADIENT.length];
                    int r = (int) Math.round(color1[0] * (1 - ombre) + color2[0] * ombre);
                    int g = (int) Math.round(color1[1] * (1 - ombre) + color2[1] * ombre);
                    int b = (int) Math.round(color1[2] * (1 - ombre) + color2[2] * ombre);
                    if(display.getDayCycle()){
                    display.setColor(i, j, r, g, b);}else{display.setColor(i, j, 0, 0, 0);}

                }
                







                if (grid[i][j] == ROCK) {
                    display.setColor(i, j, 154, 154, 154);
                }
                if (grid[i][j] == SAND) {
                    int r = (int) (Math.sin(i * 0.01) * 128 + 127);
                    int g = (int) (Math.sin(j * 0.01) * 128 + 127);
                    int b = (int) (Math.sin((i + j) * 0.01) * 128 + 127);

                    display.setColor(i, j, r, g, b);
                }

                if (grid[i][j] == FALLSAND) {
                    display.setColor(i, j, 246, 255, 108);
                }
                if (grid[i][j] == WATER) {
                    display.setColor(i, j, 0, 0, 255);
                }
                if (grid[i][j] == SPONGE) {
                    display.setColor(i, j, 255, 205, 0);
                }
                if (grid[i][j] == LAVA) {
                    display.setColor(i, j, 255, 0, 0);


                }
                if (grid[i][j] == LAVA2) {
                    display.setColor(i, j, 255, 111, 0);

                }
                if (grid[i][j] == WATER2) {
                    display.setColor(i, j, 75, 166, 255);
                }
                if (display.getTool() == HOURGLASS) {
                    display.setTool(EMPTY);
                    flip();
                }
                if (grid[i][j] == MAGMA) {
                    display.setColor(i, j, 255, 93, 34);
                }
                if (grid[i][j] == STEAM) {
                    display.setColor(i, j, 230, 244, 255);
                }
                if (grid[i][j] == WOOD) {
                    display.setColor(i, j, 137, 71, 0);
                }
                if (grid[i][j] == FIRE) {
                    display.setColor(i, j, 255, 77, 0);
                }
                if (grid[i][j] == INFECTION) {
                    display.setColor(i, j, 17, 215, 0);
                }
                if (grid[i][j] == LEAF) {
                    display.setColor(i, j, 11, 162, 0);
                }
                if (grid[i][j] == DEADLEAF) {
                    display.setColor(i, j, 182, 136, 58);
                }
                if(grid[i][j] == RAPIDINFECTION){
                    display.setColor(i, j, 193, 66, 255);
                }
                if(grid[i][j] == DIRT){
                    display.setColor(i, j, 176, 94, 0);
                }
                if(grid[i][j] == SOIL){
                    display.setColor(i, j, 88, 47, 0);
                }
                if(grid[i][j] == SAPLING){
                    display.setColor(i, j,0,255, 0);
                }
            }

        }
    }


    //called repeatedly.
    //causes one random particle to maybe do something.
    public void step() {


        int randRow = (int) (Math.random() * (grid.length - 1));
        int randCol = (int) (Math.random() * (grid[0].length - 1));
        if (grid[randRow][randCol] != EMPTY) {
            if (grid[randRow][randCol] == HOURGLASS) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARFALLSAND) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARSAPLINGS) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARFIRE) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARLAVA) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARMAGMA) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARROCK) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARSAND) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARSPONGE) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARSTEAM) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARWATER) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARWOOD) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARINFECTION) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == CLEARLEAVES) {
                grid[randRow][randCol] = EMPTY;
            }
            if (grid[randRow][randCol] == SAND) {
                if (grid[randRow][randCol] == SAND && grid[randRow + 1][randCol] == EMPTY) {
                    grid[randRow][randCol] = EMPTY;
                    grid[randRow + 1][randCol] = SAND;
                }
                if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == SAND) {
                    grid[randRow][randCol] = WATER;
                    grid[randRow + 1][randCol] = SAND;
                }
                if (grid[randRow][randCol] == SAND && grid[randRow + 1][randCol] == EMPTY) {
                    grid[randRow][randCol] = EMPTY;
                    grid[randRow + 1][randCol] = SAND;
                }
                if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == SAND) {
                    grid[randRow][randCol] = WATER2;
                    grid[randRow + 1][randCol] = SAND;
                }
                if (grid[randRow + 1][randCol] == FALLSAND && grid[randRow][randCol] == SAND) {
                    grid[randRow][randCol] = FALLSAND;
                    grid[randRow + 1][randCol] = SAND;
                }
                if (grid[randRow + 1][randCol] == LAVA && grid[randRow][randCol] == SAND) {
                    grid[randRow][randCol] = LAVA;
                    grid[randRow + 1][randCol] = SAND;
                }
                if (grid[randRow + 1][randCol] == LAVA2 && grid[randRow][randCol] == SAND) {
                    grid[randRow][randCol] = LAVA2;
                    grid[randRow + 1][randCol] = SAND;
                }
            }


            if (grid[randRow][randCol] == FALLSAND) {
                if (grid[randRow + 1][randCol] == EMPTY) {
                    if (grid[randRow + 1][randCol] == EMPTY) {
                        grid[randRow + 1][randCol] = FALLSAND;
                        grid[randRow][randCol] = EMPTY;
                    }
                    if (grid[randRow + 1][randCol] == WATER) {
                        grid[randRow + 1][randCol] = FALLSAND;
                        grid[randRow][randCol] = WATER;
                    }
                    if (grid[randRow + 1][randCol] == WATER2) {
                        grid[randRow + 1][randCol] = FALLSAND;
                        grid[randRow][randCol] = WATER2;
                    }
                } else if (Math.random() > 0.5) {
                    if (randRow != 0 && randCol != 0) {
                        if (grid[randRow + 1][randCol] == FALLSAND && grid[randRow + 1][randCol - 1] == EMPTY) {

                            grid[randRow][randCol] = EMPTY;
                            grid[randRow][randCol - 1] = FALLSAND;
                            int rr1 = ((int) (Math.random() * 3));
                            int rc1 = ((int) (Math.random() * 3));
                            if (randRow + rr1 < grid.length && randCol - rc1 >= 0)
                                if (grid[randRow + rr1][randCol - rc1] == EMPTY) {
                                    if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == FALLSAND) {
                                        grid[randRow][randCol] = WATER;
                                        grid[randRow + 1][randCol] = FALLSAND;
                                    }
                                    if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == FALLSAND) {
                                        grid[randRow][randCol] = WATER2;
                                        grid[randRow + 1][randCol] = FALLSAND;
                                    }
                                    grid[randRow + rr1][randCol - rc1] = FALLSAND;
                                }
                        }
                    } else {
                        return;
                    }
                } else {
                    if (randRow != 0 && randCol != 0)
                        if (grid[randRow + 1][randCol] == FALLSAND && grid[randRow + 1][randCol + 1] == EMPTY) {
                            grid[randRow][randCol] = EMPTY;
                            grid[randRow][randCol + 1] = FALLSAND;
                            int rr1 = ((int) (Math.random() * 3));
                            int rc1 = ((int) (Math.random() * 3));
                            if (Math.random() > 0.5) {
                                if (randRow + rr1 < grid.length - 1)
                                    if (randCol + rc1 < grid[0].length - 1)
                                        if (grid[randRow + rr1][randCol + rc1] == EMPTY) {
                                            if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == FALLSAND) {
                                                grid[randRow][randCol] = WATER;
                                                grid[randRow + 1][randCol] = FALLSAND;
                                            }
                                            if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == FALLSAND) {
                                                grid[randRow][randCol] = WATER2;
                                                grid[randRow + 1][randCol] = FALLSAND;
                                            }
                                            grid[randRow + rr1][randCol + rc1] = FALLSAND;
                                        }
                            } else {
                                if (randRow - rr1 > 0)
                                    if (randCol - rc1 > 0)
                                        if (grid[randRow - rr1][randCol - rc1] == EMPTY) {
                                            if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == FALLSAND) {
                                                grid[randRow][randCol] = WATER;
                                                grid[randRow + 1][randCol] = FALLSAND;
                                                grid[randRow + rr1][randCol + rc1] = FALLSAND;
                                            }
                                        }
                            }
                        } else {
                            if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == FALLSAND) {
                                grid[randRow][randCol] = WATER;
                                grid[randRow + 1][randCol] = FALLSAND;

                            }
                            if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == FALLSAND) {
                                grid[randRow][randCol] = WATER2;
                                grid[randRow + 1][randCol] = FALLSAND;

                            }
                        }
                }
                if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == FALLSAND) {
                    grid[randRow][randCol] = WATER;
                    grid[randRow + 1][randCol] = FALLSAND;
                }
                if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == FALLSAND) {
                    grid[randRow][randCol] = WATER2;
                    grid[randRow + 1][randCol] = FALLSAND;
                }
            }


            if (grid[randRow][randCol] == WATER) {

                if (grid[randRow + 1][randCol] == EMPTY) {
                    grid[randRow][randCol] = EMPTY;
                    grid[randRow + 1][randCol] = WATER;
                } else {
                    if (Math.random() > 0.5) {
                        if (randCol != 0)
                            if (grid[randRow][randCol - 1] == EMPTY) {
                                grid[randRow][randCol] = EMPTY;
                                grid[randRow][randCol - 1] = WATER;
                            }
                    } else {
                        if (grid[randRow][randCol + 1] == EMPTY) {
                            grid[randRow][randCol] = EMPTY;
                            grid[randRow][randCol + 1] = WATER;
                        }

                    }


                }
            }
            if (grid[randRow][randCol] == WATER2) {
                if (grid[randRow + 1][randCol] == EMPTY) {
                    grid[randRow][randCol] = EMPTY;
                    grid[randRow + 1][randCol] = WATER2;
                } else {
                    if (Math.random() > 0.5) {
                        if (randCol != 0)
                            if (grid[randRow][randCol - 1] == EMPTY) {
                                grid[randRow][randCol] = EMPTY;
                                grid[randRow][randCol - 1] = WATER2;
                            }
                    } else {
                        if (grid[randRow][randCol + 1] == EMPTY) {
                            grid[randRow][randCol] = EMPTY;
                            grid[randRow][randCol + 1] = WATER2;
                        }

                    }

                }
            }
            if (grid[randRow][randCol] == SPONGE) {
                if (randRow != grid.length && randRow != 0 && randCol != grid[0].length && randCol != 0) {
                    if (grid[randRow][randCol] == WATER) {
                        grid[randRow][randCol] = EMPTY;
                    }
                    if (isTouchingDown(SPONGE, WATER, randRow, randCol)) {
                        grid[randRow + 1][randCol] = EMPTY;
                    }
                    if (isTouchingDownRight(SPONGE, WATER, randRow, randCol)) {
                        grid[randRow + 1][randCol + 1] = EMPTY;
                    }
                    if (isTouchingRight(SPONGE, WATER, randRow, randCol)) {
                        grid[randRow][randCol + 1] = EMPTY;
                    }
                    if (isTouchingUp(SPONGE, WATER, randRow, randCol)) {
                        grid[randRow - 1][randCol] = EMPTY;
                    }
                    if (isTouchingLeft(SPONGE, WATER, randRow, randCol)) {
                        grid[randRow][randCol - 1] = EMPTY;
                    }
                    if (isTouchingUpLeft(SPONGE, WATER, randRow, randCol)) {
                        grid[randRow - 1][randCol - 1] = EMPTY;
                    }
                    if (grid[randRow][randCol] == WATER2) {
                        grid[randRow][randCol] = EMPTY;
                    }
                    if (isTouchingDown(SPONGE, WATER2, randRow, randCol)) {
                        grid[randRow + 1][randCol] = EMPTY;
                    }
                    if (isTouchingDownRight(SPONGE, WATER2, randRow, randCol)) {
                        grid[randRow + 1][randCol + 1] = EMPTY;
                    }
                    if (isTouchingRight(SPONGE, WATER2, randRow, randCol)) {
                        grid[randRow][randCol + 1] = EMPTY;
                    }
                    if (isTouchingUp(SPONGE, WATER2, randRow, randCol)) {
                        grid[randRow - 1][randCol] = EMPTY;
                    }
                    if (isTouchingLeft(SPONGE, WATER2, randRow, randCol)) {
                        grid[randRow][randCol - 1] = EMPTY;
                    }
                    if (isTouchingUpLeft(SPONGE, WATER2, randRow, randCol)) {
                        grid[randRow - 1][randCol - 1] = EMPTY;
                    }
                }
            }
            if (grid[randRow][randCol] == LAVA) {

                if (grid[randRow + 1][randCol] == EMPTY) {
                    grid[randRow][randCol] = EMPTY;
                    grid[randRow + 1][randCol] = LAVA;
                } else {
                    y += w;
                    if (y > 750000) {
                        grid[randRow][randCol] = SAND;
                        w = 100;
                        y = 0;
                    }
                    if (Math.random() > 0.5) {
                        if (randCol != 0)
                            if (grid[randRow][randCol - 1] == EMPTY) {
                                x++;
                                if (x == 3) {
                                    grid[randRow][randCol] = EMPTY;
                                    grid[randRow][randCol - 1] = LAVA;
                                    x = 0;
                                }
                            }
                    } else {
                        if (grid[randRow][randCol + 1] == EMPTY) {
                            x++;
                            if (x == 3) {
                                grid[randRow][randCol] = EMPTY;
                                grid[randRow][randCol + 1] = LAVA;
                                x = 0;
                            }
                        }
                    }

                }

            }
            if (randRow > 0 && randCol > 0 && randRow < grid.length && randCol < grid[0].length) {
                if (grid[randRow + 1][randCol] == FALLSAND && grid[randRow][randCol] == LAVA) {
                    grid[randRow + 1][randCol] = SAND;
                }
                if (grid[randRow - 1][randCol] == FALLSAND && grid[randRow][randCol] == LAVA) {
                    grid[randRow - 1][randCol] = SAND;
                }
                if (grid[randRow][randCol + 1] == FALLSAND && grid[randRow][randCol] == LAVA) {
                    grid[randRow][randCol + 1] = SAND;
                }
                if (grid[randRow][randCol - 1] == FALLSAND && grid[randRow][randCol] == LAVA) {
                    grid[randRow][randCol - 1] = SAND;
                }
            }

            if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == LAVA) {
                if (Math.random() > 0.5) {
                    grid[randRow + 1][randCol] = ROCK;
                } else {
                    grid[randRow][randCol] = ROCK;
                }
            }
            if (randRow != 0 && randRow != grid.length && randCol != 0 && randCol != grid[0].length) {
                if (grid[randRow - 1][randCol] == WATER && grid[randRow][randCol] == LAVA) {
                    if (Math.random() > 0.5) {
                        grid[randRow - 1][randCol] = ROCK;
                    } else {
                        grid[randRow][randCol] = ROCK;
                    }
                }
                if (grid[randRow][randCol + 1] == WATER && grid[randRow][randCol] == LAVA) {
                    if (Math.random() > 0.5) {
                        grid[randRow][randCol + 1] = ROCK;
                    } else {
                        grid[randRow][randCol] = ROCK;
                    }
                }
                if (grid[randRow][randCol - 1] == WATER && grid[randRow][randCol] == LAVA) {
                    if (Math.random() > 0.5) {
                        grid[randRow][randCol - 1] = ROCK;
                    } else {
                        grid[randRow][randCol] = ROCK;
                    }
                }
            } else if (randCol == grid[0].length - 1) {
                if (randRow != 0 && randRow != grid.length && randCol != 0 && randCol != grid[0].length) {
                    if (grid[randRow - 1][randCol] == WATER && grid[randRow][randCol] == LAVA) {
                        grid[randRow][randCol] = ROCK;
                    }
                    if (grid[randRow][randCol + 1] == WATER && grid[randRow][randCol] == LAVA) {
                        grid[randRow][randCol] = ROCK;
                    }
                }
            }
            if (grid[randRow][randCol] == LAVA2) {

                if (grid[randRow + 1][randCol] == EMPTY) {
                    grid[randRow][randCol] = EMPTY;
                    grid[randRow + 1][randCol] = LAVA2;
                } else {
                    y += w;
                    if (y > 700000) {
                        grid[randRow][randCol] = SAND;
                        w = 100;
                        y = 0;
                    }
                    if (Math.random() > 0.5) {
                        if (randCol != 0)
                            if (grid[randRow][randCol - 1] == EMPTY) {
                                x++;
                                if (x == 3) {
                                    grid[randRow][randCol] = EMPTY;
                                    grid[randRow][randCol - 1] = LAVA2;
                                    x = 0;
                                }
                            }
                    } else {
                        if (grid[randRow][randCol + 1] == EMPTY) {
                            x++;
                            if (x == 3) {
                                grid[randRow][randCol] = EMPTY;
                                grid[randRow][randCol + 1] = LAVA2;
                                x = 0;
                            }
                        }
                    }

                }

            }
            if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == LAVA2) {
                if (Math.random() > 0.5) {
                    grid[randRow + 1][randCol] = ROCK;
                } else {
                    grid[randRow][randCol] = ROCK;
                }
            }
            if (randRow != 0 && randRow != grid.length && randCol != 0 && randCol != grid[0].length) {
                if (grid[randRow - 1][randCol] == WATER && grid[randRow][randCol] == LAVA2) {
                    if (Math.random() > 0.5) {
                        grid[randRow - 1][randCol] = ROCK;
                    } else {
                        grid[randRow][randCol] = ROCK;
                    }
                }
                if (grid[randRow][randCol + 1] == WATER && grid[randRow][randCol] == LAVA2) {
                    if (Math.random() > 0.5) {
                        grid[randRow][randCol + 1] = ROCK;
                    } else {
                        grid[randRow][randCol] = ROCK;
                    }
                }
                if (grid[randRow][randCol - 1] == WATER && grid[randRow][randCol] == LAVA2) {
                    if (Math.random() > 0.5) {
                        grid[randRow][randCol - 1] = ROCK;
                    } else {
                        grid[randRow][randCol] = ROCK;
                    }
                }
            } else if (randCol == grid[0].length - 1) {
                if (randRow != 0 && randRow != grid.length && randCol != 0 && randCol != grid[0].length) {
                    if (grid[randRow - 1][randCol] == WATER && grid[randRow][randCol] == LAVA2) {
                        grid[randRow][randCol] = ROCK;
                    }
                    if (grid[randRow][randCol + 1] == WATER && grid[randRow][randCol] == LAVA2) {
                        grid[randRow][randCol] = ROCK;
                    }
                }
            }
            if (randRow > 0 && randCol > 0 && randRow < grid.length && randCol < grid[0].length) {
                if (grid[randRow + 1][randCol] == FALLSAND && grid[randRow][randCol] == LAVA2) {
                    grid[randRow + 1][randCol] = SAND;
                }
                if (grid[randRow - 1][randCol] == FALLSAND && grid[randRow][randCol] == LAVA2) {
                    grid[randRow - 1][randCol] = SAND;
                }
                if (grid[randRow][randCol + 1] == FALLSAND && grid[randRow][randCol] == LAVA2) {
                    grid[randRow][randCol + 1] = SAND;
                }
                if (grid[randRow][randCol - 1] == FALLSAND && grid[randRow][randCol] == LAVA2) {
                    grid[randRow][randCol - 1] = SAND;
                }
            }
            if (grid[randRow][randCol] == MAGMA) {
                if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == MAGMA) {
                    grid[randRow + 1][randCol] = STEAM;
                }
                if (grid[randRow - 1][randCol] == WATER && grid[randRow][randCol] == MAGMA) {
                    grid[randRow - 1][randCol] = STEAM;
                }
                if (grid[randRow][randCol + 1] == WATER && grid[randRow][randCol] == MAGMA) {
                    grid[randRow][randCol + 1] = STEAM;
                }
                if (grid[randRow][randCol - 1] == WATER && grid[randRow][randCol] == MAGMA) {
                    grid[randRow][randCol - 1] = STEAM;
                }
                if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == MAGMA) {
                    grid[randRow + 1][randCol] = STEAM;
                }
                if (grid[randRow - 1][randCol] == WATER2 && grid[randRow][randCol] == MAGMA) {
                    grid[randRow - 1][randCol] = STEAM;
                }
                if (grid[randRow][randCol + 1] == WATER2 && grid[randRow][randCol] == MAGMA) {
                    grid[randRow][randCol + 1] = STEAM;
                }
                if (grid[randRow][randCol - 1] == WATER && grid[randRow][randCol] == MAGMA) {
                    grid[randRow][randCol - 1] = STEAM;
                }
            }


            if (grid[randRow][randCol] == STEAM) {
                if (randRow > 0) if (grid[randRow - 1][randCol] == EMPTY) {
                    grid[randRow][randCol] = EMPTY;
                    grid[randRow - 1][randCol] = STEAM;

                }
                if (randCol != 0) {
                    if (randRow > 1) {
                        if (grid[randRow - 1][randCol] == WATER) {
                            grid[randRow][randCol] = WATER;
                            grid[randRow - 1][randCol] = STEAM;
                        }
                        if (grid[randRow - 1][randCol] == WATER2) {
                            grid[randRow][randCol] = WATER2;
                            grid[randRow - 1][randCol] = STEAM;
                        }
                        if (grid[randRow - 1][randCol] == FALLSAND) {
                            grid[randRow][randCol] = FALLSAND;
                            grid[randRow - 1][randCol] = STEAM;

                        }
                        if (grid[randRow - 1][randCol] == SAND) {
                            grid[randRow][randCol] = SAND;
                            grid[randRow - 1][randCol] = STEAM;
                        }
                    }
                }
                if (randRow != 0) {
                    if (Math.random() > 0.999) {
                        if (Math.random() > 0.5) {
                            grid[randRow][randCol + 1] = WATER;
                            grid[randRow][randCol] = EMPTY;
                        } else {
                            grid[randRow][randCol + 1] = WATER2;
                            grid[randRow][randCol] = EMPTY;
                        }
                    }
                    if (Math.random() > 0.5) {
                        if (randCol != 0) {
                            if (grid[randRow][randCol - 1] == EMPTY && grid[randRow][randCol] == STEAM) {
                                grid[randRow][randCol] = EMPTY;
                                grid[randRow][randCol - 1] = STEAM;
                                if (Math.random() > 0.99999) {
                                    if (Math.random() > 0.5) {
                                        grid[randRow][randCol - 1] = WATER;
                                        grid[randRow][randCol] = EMPTY;
                                    } else {
                                        grid[randRow][randCol - 1] = WATER2;
                                        grid[randRow][randCol] = EMPTY;
                                    }
                                }
                            }
                        }
                    } else {
                        if (grid[randRow][randCol + 1] == EMPTY && grid[randRow][randCol] == STEAM) {
                            grid[randRow][randCol] = EMPTY;
                            grid[randRow][randCol + 1] = STEAM;
                            if (Math.random() > 0.999999) {
                                if (Math.random() > 0.5) {
                                    grid[randRow][randCol + 1] = WATER;
                                    grid[randRow][randCol] = EMPTY;
                                } else {
                                    grid[randRow][randCol + 1] = WATER2;
                                    grid[randRow][randCol] = EMPTY;
                                }
                            }
                        }
                    }
                }
            }
            if (grid[randRow][randCol] == WOOD) {
                if ((grid[randRow][randCol] == WOOD) && (grid[randRow + 1][randCol] == LAVA || grid[randRow + 1][randCol] == FIRE)) {
                    if (Math.random() > 0.99) {
                        grid[randRow][randCol] = FIRE;
                    } else {
                        return;
                    }
                }
                if ((grid[randRow][randCol] == WOOD) && (grid[randRow - 1][randCol] == LAVA || grid[randRow - 1][randCol] == FIRE)) {
                    if (Math.random() > 0.99) {
                        grid[randRow][randCol] = FIRE;
                    } else {
                        return;
                    }
                }
                if ((grid[randRow][randCol] == WOOD) && (grid[randRow][randCol + 1] == LAVA || grid[randRow][randCol + 1] == FIRE)) {
                    if (Math.random() > 0.99) {
                        grid[randRow][randCol] = FIRE;
                    } else {
                        return;
                    }
                }
                if ((grid[randRow][randCol] == WOOD) && (grid[randRow][randCol - 1] == LAVA || grid[randRow][randCol - 1] == FIRE)) {
                    if (Math.random() > 0.99) {
                        grid[randRow][randCol] = FIRE;
                    } else {
                        return;
                    }
                }
            }
            if (grid[randRow][randCol] == FIRE) {
                if (randRow < grid.length - 1) {
                    if (grid[randRow + 1][randCol] != WOOD || grid[randRow - 1][randCol] != WOOD || grid[randRow][randCol + 1] != WOOD || grid[randRow][randCol - 1] != WOOD || grid[randRow + 1][randCol] != DEADLEAF || grid[randRow - 1][randCol] != DEADLEAF || grid[randRow][randCol + 1] != DEADLEAF || grid[randRow][randCol - 1] != DEADLEAF) {
                        if (randRow != 0)
                            if (grid[randRow - 1][randCol] != WOOD) {
                                if (grid[randRow + 1][randCol] == EMPTY) {
                                    grid[randRow + 1][randCol] = FIRE;
                                    grid[randRow][randCol] = EMPTY;
                                }
                            }
                    }
                }
                if (v > 500) {
                    grid[randRow][randCol] = EMPTY;
                    v = 0;
                } else {
                    v++;
                }
                if ((grid[randRow + 1][randCol] == WATER || grid[randRow + 1][randCol] == STEAM)) {
                    grid[randRow][randCol] = EMPTY;
                    if (grid[randRow + 1][randCol] == WATER) {
                        grid[randRow + 1][randCol] = STEAM;
                    }
                    if (grid[randRow + 1][randCol] == STEAM) {
                        grid[randRow + 1][randCol] = STEAM;
                    }
                }
                if (randRow > 0) {
                    if ((grid[randRow - 1][randCol] == WATER || grid[randRow - 1][randCol] == STEAM)) {
                        grid[randRow][randCol] = EMPTY;
                        if (grid[randRow - 1][randCol] == WATER) {
                            grid[randRow - 1][randCol] = STEAM;
                        }
                        if (grid[randRow - 1][randCol] == STEAM) {
                            grid[randRow - 1][randCol] = STEAM;
                        }
                    }
                    if ((grid[randRow][randCol + 1] == WATER || grid[randRow][randCol + 1] == STEAM)) {
                        grid[randRow][randCol] = EMPTY;
                        if (grid[randRow][randCol + 1] == WATER) {
                            grid[randRow][randCol + 1] = STEAM;
                        }
                        if (grid[randRow][randCol + 1] == STEAM) {
                            grid[randRow][randCol + 1] = STEAM;
                        }
                    }
                    if ((grid[randRow][randCol - 1] == WATER || grid[randRow][randCol - 1] == STEAM)) {
                        grid[randRow][randCol] = EMPTY;
                        if (grid[randRow][randCol - 1] == WATER) {
                            grid[randRow][randCol - 1] = STEAM;
                        }
                        if (grid[randRow][randCol - 1] == STEAM) {
                            grid[randRow][randCol - 1] = STEAM;
                        }
                    }
                }
            }
            if (grid[randRow][randCol] == INFECTION) {
                if (grid[randRow][randCol] == INFECTION) {
                    if (randRow != 0 && randCol != 0 && randRow < grid.length && randCol < grid[0].length) {
                        if ((grid[randRow][randCol] == INFECTION) && grid[randRow + 1][randCol] != EMPTY&& grid[randRow + 1][randCol] != RAPIDINFECTION) {
                            if (Math.random() > 0.99) {
                                grid[randRow + 1][randCol] = INFECTION;
                                u += 2;
                            } else {
                                if (Math.random() > 0.999) {
                                    t--;
                                }
                                return;
                            }
                        }
                        if ((grid[randRow][randCol] == INFECTION) && grid[randRow - 1][randCol] != EMPTY&& grid[randRow - 1][randCol] != RAPIDINFECTION) {
                            if (Math.random() < 0.99) {
                                grid[randRow - 1][randCol] = INFECTION;
                                u += 2;
                            } else {
                                if (Math.random() > 0.999) {
                                    t--;
                                }
                                return;
                            }
                        }
                        if ((grid[randRow][randCol] == INFECTION) && grid[randRow][randCol + 1] != EMPTY&& grid[randRow][randCol + 1] != RAPIDINFECTION) {
                            if (Math.random() < 0.99) {
                                grid[randRow][randCol + 1] = INFECTION;
                                u += 2;
                            } else {
                                if (Math.random() > 0.999) {
                                    t--;
                                }
                                return;
                            }
                        }
                        if ((grid[randRow][randCol] == INFECTION) && grid[randRow][randCol - 1] != EMPTY&& grid[randRow][randCol - 1] != RAPIDINFECTION) {
                            if (Math.random() < 0.99) {
                                grid[randRow][randCol - 1] = INFECTION;
                                u += 2;
                            } else {
                                if (Math.random() > 0.999) {
                                    t--;
                                }
                                return;
                            }
                        }
                    }
                }
                if (u > t) {
                    grid[randRow][randCol] = EMPTY;
                    u = 0;
                    t++;
                    if(Math.random()>0.9999999){
                        grid[randRow][randCol] = RAPIDINFECTION;
                    }
                }
                u++;
            }


            if (grid[randRow][randCol] == LEAF) {
                if (display.getTime() == 0) {
                    s = 0;
                }
                if ((grid[randRow][randCol] == LEAF) && grid[randRow + 1][randCol] != WOOD) {
                    if (Math.random() < 0.99) {
                        if (grid[randRow + 1][randCol] == DEADLEAF) {
                            s += display.getTime() * 2;
                        } else {
                            s += display.getTime();
                        }
                    } else {
                        if (Math.random() > 0.999) {
                            r--;
                        }
                    }
                }else{s = 0;}
                if ((grid[randRow][randCol] == LEAF) && grid[randRow - 1][randCol] != WOOD) {
                    if (Math.random() < 0.99) {
                        if (grid[randRow - 1][randCol] == DEADLEAF) {
                            s += display.getTime() * 2;
                        } else {
                            s += display.getTime();
                        }
                    } else {
                        if (Math.random() > 0.999) {
                            r--;
                        }
                    }
                }else{s = 0;}
                if ((grid[randRow][randCol] == LEAF) && grid[randRow][randCol + 1] != WOOD) {
                    if (Math.random() < 0.99) {
                        if (grid[randRow][randCol + 1] == DEADLEAF) {
                            s += display.getTime() * 2;
                        } else {
                            s += display.getTime();
                        }
                    } else {
                        if (Math.random() > 0.999) {
                            r--;
                        }
                    }
                }else{s = 0;}
                if ((grid[randRow][randCol] == LEAF) && grid[randRow][randCol - 1] != WOOD) {
                    if (Math.random() < 0.99) {
                        if (grid[randRow][randCol - 1] == DEADLEAF) {
                            s += display.getTime() * 2;
                        }
                        s += display.getTime();
                    } else {
                        if (Math.random() > 0.999) {
                            r--;
                        }
                    }
                }else{s = 0;}
                if (s > r) {
                    s = 0;
                    grid[randRow][randCol] = DEADLEAF;
                    r++;
                }
            }


            if (grid[randRow][randCol] == DEADLEAF) {
                if ((grid[randRow][randCol] == DEADLEAF) && (grid[randRow + 1][randCol] == LAVA || grid[randRow + 1][randCol] == FIRE)) {
                    if (Math.random() < 0.5) {
                        grid[randRow][randCol] = FIRE;
                    } else {
                        return;
                    }
                }
                if ((grid[randRow][randCol] == DEADLEAF) && (grid[randRow - 1][randCol] == LAVA || grid[randRow - 1][randCol] == FIRE)) {
                    if (Math.random() < 0.5) {
                        grid[randRow][randCol] = FIRE;
                    } else {
                        return;
                    }
                }
                if ((grid[randRow][randCol] == DEADLEAF) && (grid[randRow][randCol + 1] == LAVA || grid[randRow][randCol + 1] == FIRE)) {
                    if (Math.random() < 0.5) {
                        grid[randRow][randCol] = FIRE;
                    } else {
                        return;
                    }
                }
                if ((grid[randRow][randCol] == DEADLEAF) && (grid[randRow][randCol - 1] == LAVA || grid[randRow][randCol - 1] == FIRE)) {
                    if (Math.random() < 0.5) {
                        grid[randRow][randCol] = FIRE;
                    } else {
                        return;
                    }
                }
            }
            if (grid[randRow][randCol] == RAPIDINFECTION) {
                if (randRow != 0 && randCol != 0 && randRow < grid.length && randCol < grid[0].length) {
                    if ((grid[randRow][randCol] == RAPIDINFECTION) && grid[randRow + 1][randCol] != EMPTY) {
                        if (Math.random() > 0.99) {
                            grid[randRow + 1][randCol] = RAPIDINFECTION;
                            q += 2;
                        } else {
                            if (Math.random() > 0.9) {
                                r--;
                            }
                            return;
                        }
                    }
                    if ((grid[randRow][randCol] == RAPIDINFECTION) && grid[randRow - 1][randCol] != EMPTY) {
                        if (Math.random() < 0.99) {
                            grid[randRow - 1][randCol] = RAPIDINFECTION;
                            q += 2;
                        } else {
                            if (Math.random() > 0.9) {
                                r--;
                            }
                            return;
                        }
                    }
                    if ((grid[randRow][randCol] == RAPIDINFECTION) && grid[randRow][randCol + 1] != EMPTY) {
                        if (Math.random() < 0.99) {
                            grid[randRow][randCol + 1] = RAPIDINFECTION;
                            q += 2;
                        } else {
                            if (Math.random() > 0.9) {
                                p--;
                            }
                            return;
                        }
                    }
                    if ((grid[randRow][randCol] == RAPIDINFECTION) && grid[randRow][randCol - 1] != EMPTY) {
                        if (Math.random() < 0.99) {
                            grid[randRow][randCol - 1] = RAPIDINFECTION;
                            q += 2;
                        } else {
                            if (Math.random() > 0.9) {
                                p--;
                            }
                            return;
                        }
                    }
                }
                if (q > p) {
                    grid[randRow][randCol] = EMPTY;
                    q = 0;
                    p--;
                }
                q++;
            }



            if (grid[randRow][randCol] == DIRT) {
                if (randRow != grid.length && randRow != 0 && randCol != grid[0].length && randCol != 0) {

                    if (isTouchingDown(DIRT, WATER, randRow, randCol)) {
                        grid[randRow + 1][randCol] = SOIL;
                    }
                    if (isTouchingDownRight(DIRT, WATER, randRow, randCol)) {
                        grid[randRow + 1][randCol + 1] = SOIL;
                    }
                    if (isTouchingRight(DIRT, WATER, randRow, randCol)) {
                        grid[randRow][randCol + 1] = SOIL;
                    }
                    if (isTouchingUp(DIRT, WATER, randRow, randCol)) {
                        grid[randRow - 1][randCol] = SOIL;
                    }
                    if (isTouchingLeft(DIRT, WATER, randRow, randCol)) {
                        grid[randRow][randCol - 1] = SOIL;
                    }
                    if (isTouchingUpLeft(DIRT, WATER, randRow, randCol)) {
                        grid[randRow - 1][randCol - 1] = SOIL;
                    }
                    if (isTouchingDown(DIRT, WATER2, randRow, randCol)) {
                        grid[randRow + 1][randCol] = SOIL;
                    }
                    if (isTouchingDownRight(DIRT, WATER2, randRow, randCol)) {
                        grid[randRow + 1][randCol + 1] = SOIL;
                    }
                    if (isTouchingRight(DIRT, WATER2, randRow, randCol)) {
                        grid[randRow][randCol + 1] = SOIL;
                    }
                    if (isTouchingUp(DIRT, WATER2, randRow, randCol)) {
                        grid[randRow - 1][randCol] = SOIL;
                    }
                    if (isTouchingLeft(DIRT, WATER2, randRow, randCol)) {
                        grid[randRow][randCol - 1] = SOIL;
                    }
                    if (isTouchingUpLeft(DIRT, WATER2, randRow, randCol)) {
                        grid[randRow - 1][randCol - 1] = SOIL;
                    }
                }

                if (grid[randRow + 1][randCol] == EMPTY) {
                    if (grid[randRow + 1][randCol] == EMPTY) {
                        grid[randRow + 1][randCol] = DIRT;
                        grid[randRow][randCol] = EMPTY;
                    }
                    if (grid[randRow + 1][randCol] == WATER) {
                        grid[randRow + 1][randCol] = DIRT;
                        grid[randRow][randCol] = WATER;
                    }
                    if (grid[randRow + 1][randCol] == WATER2) {
                        grid[randRow + 1][randCol] = DIRT;
                        grid[randRow][randCol] = WATER2;
                    }
                } else if (Math.random() > 0.5) {
                    if (randRow != 0 && randCol != 0) {
                        if (grid[randRow + 1][randCol] == DIRT && grid[randRow + 1][randCol - 1] == EMPTY) {

                            grid[randRow][randCol] = EMPTY;
                            grid[randRow][randCol - 1] = DIRT;
                            int rr1 = ((int) (Math.random() * 3));
                            int rc1 = ((int) (Math.random() * 3));
                            if (randRow + rr1 < grid.length && randCol - rc1 >= 0)
                                if (grid[randRow + rr1][randCol - rc1] == EMPTY) {
                                    if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == DIRT) {
                                        grid[randRow][randCol] = WATER;
                                        grid[randRow + 1][randCol] = DIRT;
                                    }
                                    if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == DIRT) {
                                        grid[randRow][randCol] = WATER2;
                                        grid[randRow + 1][randCol] = DIRT;
                                    }
                                    grid[randRow + rr1][randCol - rc1] = DIRT;
                                }
                        }
                    } else {
                        return;
                    }
                } else {
                    if (randRow != 0 && randCol != 0)
                        if (grid[randRow + 1][randCol] == DIRT && grid[randRow + 1][randCol + 1] == EMPTY) {
                            grid[randRow][randCol] = EMPTY;
                            grid[randRow][randCol + 1] = DIRT;
                            int rr1 = ((int) (Math.random() * 3));
                            int rc1 = ((int) (Math.random() * 3));
                            if (Math.random() > 0.5) {
                                if (randRow + rr1 < grid.length - 1)
                                    if (randCol + rc1 < grid[0].length - 1)
                                        if (grid[randRow + rr1][randCol + rc1] == EMPTY) {
                                            if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == DIRT) {
                                                grid[randRow][randCol] = WATER;
                                                grid[randRow + 1][randCol] = DIRT;
                                            }
                                            if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == DIRT) {
                                                grid[randRow][randCol] = WATER2;
                                                grid[randRow + 1][randCol] = DIRT;
                                            }
                                            grid[randRow + rr1][randCol + rc1] = DIRT;
                                        }
                            } else {
                                if (randRow - rr1 > 0)
                                    if (randCol - rc1 > 0)
                                        if (grid[randRow - rr1][randCol - rc1] == EMPTY) {
                                            if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == DIRT) {
                                                grid[randRow][randCol] = WATER;
                                                grid[randRow + 1][randCol] = DIRT;
                                                grid[randRow + rr1][randCol + rc1] = DIRT;
                                            }
                                        }
                            }
                        } else {
                            if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == DIRT) {
                                grid[randRow][randCol] = WATER;
                                grid[randRow + 1][randCol] = DIRT;

                            }
                            if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == DIRT) {
                                grid[randRow][randCol] = WATER2;
                                grid[randRow + 1][randCol] = DIRT;

                            }
                        }
                }
                if (grid[randRow + 1][randCol] == WATER && grid[randRow][randCol] == DIRT) {
                    grid[randRow][randCol] = WATER;
                    grid[randRow + 1][randCol] = DIRT;
                }
                if (grid[randRow + 1][randCol] == WATER2 && grid[randRow][randCol] == DIRT) {
                    grid[randRow][randCol] = WATER2;
                    grid[randRow + 1][randCol] = DIRT;
                }
            }
            if(grid[randRow][randCol] == SOIL){
                if (randRow != grid.length && randRow != 0 && randCol != grid[0].length && randCol != 0) {


                        if (isTouchingDown(SOIL, WATER, randRow, randCol)) {
                            grid[randRow + 1][randCol] = EMPTY;
                            waterCount++;
                                    if (isTouchingDown(SOIL, DIRT, randRow + 1, randCol)) {
                                        grid[randRow + 1][randCol] = SOIL;

                                }
                        }
                        if (isTouchingDownRight(SOIL, WATER, randRow, randCol)) {
                            grid[randRow + 1][randCol + 1] = EMPTY;
                            waterCount++;
                                    if (isTouchingDownRight(SOIL, DIRT, randRow + 1, randCol + 1)) {
                                        grid[randRow + 1][randCol + 1] = EMPTY;

                                }
                        }
                        if (isTouchingDownLeft(SOIL, WATER, randRow, randCol)) {
                            grid[randRow + 1][randCol - 1] = EMPTY;
                            waterCount++;
                                    if (isTouchingDownLeft(SOIL, DIRT, randRow + 1, randCol - 1)) {
                                        grid[randRow + 1][randCol - 1] = SOIL;

                                }
                        }
                        if (isTouchingRight(SOIL, WATER, randRow, randCol)) {
                            grid[randRow][randCol + 1] = EMPTY;
                            waterCount++;
                                if (isTouchingDownRight(SOIL, DIRT, randRow + 1, randCol + 1)) {
                                    grid[randRow + 1][randCol + 1] = EMPTY;

                            }
                        }
                        if (isTouchingUp(SOIL, WATER, randRow, randCol)) {
                            grid[randRow - 1][randCol] = EMPTY;
                            waterCount++;
                                if (isTouchingDown(SOIL, DIRT, randRow + 1, randCol)) {
                                    grid[randRow + 1][randCol] = SOIL;

                            }
                        }
                        if (isTouchingLeft(SOIL, WATER, randRow, randCol)) {
                            grid[randRow][randCol - 1] = EMPTY;
                            waterCount++;
                                if(isTouchingDownRight(SOIL, DIRT, randRow + 1, randCol - 1)) {
                                    grid[randRow + 1][randCol - 1] = SOIL;

                            }
                        }
                        if (isTouchingUpLeft(SOIL, WATER, randRow, randCol)) {
                            grid[randRow - 1][randCol - 1] = EMPTY;
                            waterCount++;
                                if (isTouchingDownLeft(SOIL, DIRT, randRow + 1, randCol - 1)) {
                                    grid[randRow + 1][randCol - 1] = SOIL;

                            }
                        }
                        if (isTouchingDown(SOIL, WATER2, randRow, randCol)) {
                            grid[randRow + 1][randCol] = EMPTY;

                            waterCount++;
                                    if (isTouchingDown(SOIL, DIRT, randRow, randCol)) {
                                        grid[randRow + 1][randCol] = SOIL;

                                }
                        }
                        if (isTouchingDownRight(SOIL, WATER2, randRow, randCol)) {
                            grid[randRow + 1][randCol + 1] = EMPTY;

                            waterCount++;
                                    if (isTouchingDownRight(SOIL, DIRT, randRow, randCol)) {
                                        grid[randRow + 1][randCol + 1] = SOIL;

                                }
                        }
                        if (isTouchingDownLeft(SOIL, WATER2, randRow, randCol)) {
                            grid[randRow + 1][randCol - 1] = EMPTY;
                            waterCount++;
                                    if (isTouchingDownLeft(SOIL, DIRT, randRow, randCol)) {
                                        grid[randRow + 1][randCol - 1] = SOIL;

                                }
                        }
                        if (isTouchingRight(SOIL, WATER2, randRow, randCol)) {
                            grid[randRow][randCol + 1] = EMPTY;
                            waterCount++;
                                if (isTouchingDownLeft(SOIL, DIRT, randRow, randCol)) {
                                    grid[randRow + 1][randCol - 1] = SOIL;

                            }
                        }
                        if (isTouchingUp(SOIL, WATER2, randRow, randCol)) {
                            grid[randRow - 1][randCol] = EMPTY;
                            waterCount++;
                                if (isTouchingDown(SOIL, DIRT, randRow, randCol)) {
                                    grid[randRow + 1][randCol] = SOIL;

                            }
                        }
                        if (isTouchingLeft(SOIL, WATER2, randRow, randCol)) {
                            grid[randRow][randCol - 1] = EMPTY;
                            waterCount++;
                                if(isTouchingRight(SOIL, DIRT, randRow, randCol - 1)) {
                                    grid[randRow][randCol - 1] = SOIL;
                                }

                        }
                        if (isTouchingUpLeft(SOIL, WATER2, randRow, randCol)) {
                            grid[randRow - 1][randCol - 1] = EMPTY;
                            waterCount++;
                                if (isTouchingDownLeft(SOIL, DIRT, randRow, randCol)) {
                                    grid[randRow + 1][randCol - 1] = SOIL;
                                }
                    }
                }
                if(isTouchingDownLeft(SOIL, DIRT, randRow, randCol)){
                    if(Math.random()>0.9995){
                        if(waterCount < 10000000)
                        grid[randRow+1][randCol-1] = SOIL;
                    }
                }
                if(isTouchingDownRight(SOIL, DIRT, randRow, randCol)){
                    if(Math.random()>0.9995){
                        if(waterCount < 10000000)
                        grid[randRow+1][randCol+1] = SOIL;
                    }
                }

            }
            if(grid[randRow][randCol] == SAPLING) {
                seedCount += display.getTime()*4;
                if (grid[randRow + 1][randCol] != SOIL) {
                    if (grid[randRow + 1][randCol] == EMPTY) {
                        grid[randRow + 1][randCol] = SAPLING;
                        grid[randRow][randCol] = EMPTY;

                    }
                    if (grid[randRow + 1][randCol] == WATER) {
                        grid[randRow][randCol] = WATER;
                        grid[randRow + 1][randCol] = SAPLING;
                    }
                    if (grid[randRow + 1][randCol] == WATER2) {
                        grid[randRow][randCol] = WATER2;
                        grid[randRow + 1][randCol] = SAPLING;
                    }
                }else{
                    if(grid[randRow+1][randCol] == SOIL && grid[randRow][randCol] == SAPLING){
                        if(Math.random()>0.5){
                            if(seedCount > 1000) {
                                if (Math.random() > 0.6) {
                                    //tree type 1

                                    if (randRow - 6 > 0 && randCol - 3 > 0 && randCol + 3 < grid[0].length) {
                                        if (grid[randRow][randCol + 3] != WOOD && grid[randRow][randCol + 2] != WOOD && grid[randRow][randCol + 1] != WOOD && grid[randRow][randCol - 3] != WOOD && grid[randRow][randCol - 2] != WOOD && grid[randRow][randCol - 1] != WOOD)
                                            seedCount /= 8;
                                        grid[randRow][randCol] = WOOD;
                                        grid[randRow - 1][randCol] = WOOD;
                                        grid[randRow - 2][randCol] = WOOD;
                                        grid[randRow - 3][randCol] = LEAF;
                                        grid[randRow - 4][randCol] = LEAF;
                                        grid[randRow - 4][randCol + 1] = LEAF;
                                        grid[randRow - 4][randCol - 1] = LEAF;
                                        grid[randRow - 3][randCol + 1] = LEAF;
                                        grid[randRow - 3][randCol - 1] = LEAF;
                                        grid[randRow - 3][randCol + 2] = LEAF;
                                        grid[randRow - 3][randCol - 2] = LEAF;
                                    }
                                } else if (Math.random() > 0.6) {
                                    //tree type 2
                                    if (randRow - 6 > 0 && randCol - 3 > 0 && randCol + 3 < grid[0].length) {
                                        if (grid[randRow][randCol + 3] != WOOD && grid[randRow][randCol + 2] != WOOD && grid[randRow][randCol + 1] != WOOD && grid[randRow][randCol - 3] != WOOD && grid[randRow][randCol - 2] != WOOD && grid[randRow][randCol - 1] != WOOD)
                                            seedCount /= 8;
                                        grid[randRow][randCol] = WOOD;
                                        grid[randRow][randCol+1] = WOOD;
                                        grid[randRow - 1][randCol] = WOOD;
                                        grid[randRow - 2][randCol] = WOOD;
                                        grid[randRow - 3][randCol] = LEAF;
                                        grid[randRow - 4][randCol] = LEAF;
                                        grid[randRow - 1][randCol+1] = WOOD;
                                        grid[randRow - 2][randCol+1] = WOOD;
                                        grid[randRow - 3][randCol+1] = LEAF;
                                        grid[randRow - 4][randCol+1] = LEAF;
                                        grid[randRow - 4][randCol + 1] = LEAF;
                                        grid[randRow - 4][randCol - 1] = LEAF;
                                        grid[randRow - 5][randCol + 1] = LEAF;
                                        grid[randRow - 5][randCol - 1] = LEAF;
                                        grid[randRow - 3][randCol + 1] = LEAF;
                                        grid[randRow - 3][randCol - 1] = LEAF;
                                        grid[randRow - 3][randCol + 2] = LEAF;
                                        grid[randRow - 3][randCol - 2] = LEAF;
                                        grid[randRow - 4][randCol + 2] = LEAF;
                                        grid[randRow - 4][randCol - 2] = LEAF;
                                        grid[randRow - 5][randCol + 2] = LEAF;
                                        grid[randRow - 5][randCol - 2] = LEAF;
                                        grid[randRow - 3][randCol + 2] = LEAF;
                                        grid[randRow - 3][randCol - 2] = LEAF;
                                        grid[randRow - 3][randCol + 3] = LEAF;
                                        grid[randRow - 3][randCol - 3] = LEAF;
                                    }
                                }
                            } else if (Math.random()>0.9 || seedCount > 2000) {
                                grid[randRow][randCol] = EMPTY;
                                seedCount = 0;
                            }
                        }
                    }
                    else if(grid[randRow+1][randCol] != SOIL &&grid[randRow+1][randCol] != EMPTY){grid[randRow][randCol] = EMPTY;}
                }
            }

        }
    }
    private int lerp(int a, int b, double factor) {
        return (int) (a + (b - a) * factor);
    }
    private int interpolate(int start, int end, int steps, double time) {
        int range = end - start;
        int stepSize = range / steps;
        int step = (int)(time * steps);
        int value = start + stepSize * step;
        return value;
    }




    public boolean isTouchingUp(int material,int tMat, int row, int col){
        if(row-1>0)
        if(grid[row][col] == material && grid[row-1][col] == tMat)
        {
            return true;

        }
        return false;
    }
    public boolean isTouchingDown(int material,int tMat, int row, int col){
        if(row + 1 <grid.length)
        if(grid[row][col] == material && grid[row+1][col] == tMat)
        {
            return true;

        }
        return false;
    }
    public boolean isTouchingLeft(int material,int tMat, int row, int col){
        if( col - 1> 0)
        if(grid[row][col] == material && grid[row][col-1] == tMat)
        {
            return true;

        }
        return false;
    }
    public boolean isTouchingRight(int material,int tMat, int row, int col){
        if(col + 1 < grid[0].length)
        if(grid[row][col] == material && grid[row][col+1] == tMat)
        {
            return true;
        }
        return false;
    }
    public boolean isTouchingUpRight(int material,int tMat, int row, int col){
        if(row -1>0 && col + 1 < grid[0].length)
        if(grid[row][col] == material && grid[row-1][col+1] == tMat)
        {
            return true;

        }
        return false;
    }
    public boolean isTouchingDownLeft(int material,int tMat, int row, int col){
        if(row + 1 < grid.length && col - 1 > 0) {
            if (grid[row][col] == material && grid[row + 1][col - 1] == tMat) {
                return true;
            }

        }
        return false;
    }
    public boolean isTouchingUpLeft(int material,int tMat, int row, int col){
        if(row-1>0 && col - 1 > 0)
        if(grid[row][col] == material && grid[row-1][col-1] == tMat)
        {
            return true;
        }
        return false;
    }
    public boolean isTouchingDownRight(int material,int tMat, int row, int col){
        if(row + 1 <grid.length && col + 1 < grid[0].length)
        if(grid[row][col] == material && grid[row+1][col+1] == tMat)
        {
            return true;
        }
        return false;
    }


  public void flip(){
    for (int k = 0; k < (grid.length / 2); k++) {
        int[] temp = grid[k];
        grid[k] = grid[grid.length - k - 1];
        grid[grid.length - k - 1] = temp;
      }
}

  public int getParticles(){
    int count = 0;
    for(int i = 0; i<grid.length; i++){
      for(int j = 0; j<grid[0].length; j++){
        if(grid[i][j] != EMPTY){
          count ++;
        }
      }
    }
    return count;
  }
  public int getWaterParticles(){
    int count = 0;
    for(int i = 0; i<grid.length; i++){
      for(int j = 0; j<grid[0].length; j++){
        if(grid[i][j] == WATER){
          count ++;
        }
      }
    }
    return count;
  }
    public int countCollums( int collum, int type){
    int total = 0;
    int row = 0;
    while(collum != grid[0].length){
      if(grid[row][collum] == type){
        total ++;
        row ++;
      }
    }
    return total;
    }
  public int countRows(int row, int type){
    int total = 0;
    int collum = 0;
    while(row != grid.length){
      if(grid[row][collum] == type){
        total ++;
        collum ++;
      }
    }
    return total;
  }

  public void run()
  {
    while (true)
    {
      for (int i = 0; i < display.getSpeed(); i++) {
        if(play){
        step();}}
        updateDisplay();
        display.repaint();
        display.pause(1);  //wait for redrawing and for mouse
        int[] mouseLoc = display.getMouseLocation();
        if (mouseLoc != null)  //test if mouse clicked
          locationClicked(mouseLoc[0], mouseLoc[1], display.getTool());
    }
  }
}
