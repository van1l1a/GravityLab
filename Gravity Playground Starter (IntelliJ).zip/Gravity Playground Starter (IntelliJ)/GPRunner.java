/*
click on empty then double press the space bar to pause and unpause, after that, the program can be paused at any button or materialall the clear buttons clear certian materials(with exception to the clear button which clears all)
strong sand is the heaviest falling material, and it's a rainbow because I want it to be
*/
public class GPRunner
{
  public static void main(String[] args) throws InterruptedException {
    int height = 364;
    int width = 540;
    GPPhysics lab1 = new GPPhysics(height, width);
    lab1.run();
  }
}
//int height = 379;
//int width = 540;
// int height = 360;
//    int width = 380;